﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ClassERP_project
{
    public partial class GRN : Form
    {
        public GRN()
        {
            InitializeComponent();
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            try{
            mycon c = new mycon();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select POID from PO where Status='"+"open"+"' and Approve='"+"activate"+"'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["POID"]);
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

     
        }
        string pid;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            mycon c = new mycon();
            try{
            // fetching PID AND PQTY for POProduct...
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select PID, PQty from POProducts where POID='"+comboBox1.Text+"' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox1.Text = dr["PID"].ToString();
                textBox2.Text=dr["PQty"].ToString();
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

            //fething pname from product tble
            OleDbConnection conn1 = new OleDbConnection();
            try{
            conn1.ConnectionString = c.ConnectionString;
            conn1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select *From Products where PID='"+textBox1.Text+"' ", conn1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
             textBox4.Text=dr1["Pname"].ToString();
             textBox5.Text = dr1["BP"].ToString();
            }

            conn1.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            
            //fetching VID and date
            try
            {
            OleDbConnection conn2 = new OleDbConnection();
            conn2.ConnectionString =c.ConnectionString ;
            conn2.Open();
            OleDbCommand cmd2 = new OleDbCommand("select VID , DDate , TotalAmount from PO where Poid='" + comboBox1.Text + "' ", conn2);
            OleDbDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                textBox4.Text = dr2["VID"].ToString();
                textBox3.Text = dr2["DDate"].ToString();
                textBox5.Text = dr2["TotalAmount"].ToString();
            }

            conn2.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            comboBox2.Text = comboBox1.Text + "/GRN";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                mycon c = new mycon();
                // fetching PID AND PQTY for POProduct...
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionString;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("insert into GRN (GRNID,BaseDocument,Status,VID,DCDate,GRNDate,Totalprice,Remarks) values(@GRNID,@BaseDocument,@Status,@VID,@DCDate,@GRNDate,@Totalprice,@Remarks)", conn);
                cmd.Parameters.AddWithValue("GRNID", comboBox2.Text);
                cmd.Parameters.AddWithValue("BaseDocument", comboBox1.Text);
                cmd.Parameters.AddWithValue("Status", "open");
                cmd.Parameters.AddWithValue("VID", textBox4.Text);
                cmd.Parameters.AddWithValue("DCDate", textBox3.Text);
                cmd.Parameters.AddWithValue("DDate", dateTimePicker1.Text);
                cmd.Parameters.AddWithValue("Totalprice", textBox5.Text);
                cmd.Parameters.AddWithValue("Remarks", richTextBox1.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                //update status
                OleDbConnection conn1 = new OleDbConnection();
                conn1.ConnectionString = c.ConnectionString;
                conn1.Open();
                OleDbCommand cmd1 = new OleDbCommand("update PO set Status='" + "Close" + "' where POID='" + comboBox1.Text + "'", conn1);
                OleDbDataReader dr1 = cmd1.ExecuteReader();

                MessageBox.Show("GRN COMPLETED");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox3_Click(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            try{
            mycon c = new mycon();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select GRNID from GRN where Status='" +"open"+ "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["GRNID"]);
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {//fetch poid from grn
            try{
            mycon c = new mycon();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString =c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select BaseDocument from GRN where GRNID='"+comboBox3.Text+ "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox6.Text=(dr["BaseDocument"]).ToString();
            }

            conn.Close();
            //fetching pid and pquantity
            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString = c.ConnectionString;
            conn1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select PID ,PQty from POProducts where POID='"+textBox6.Text+"' ", conn1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                textBox7.Text = (dr1["PID"]).ToString();
                f=textBox7.Text;
                textBox8.Text = (dr1["PQty"]).ToString();

            }
            conn1.Close();
            //fetching price
            OleDbConnection conn2 = new OleDbConnection();
            conn2.ConnectionString = c.ConnectionString;
            conn2.Open();
            
            OleDbCommand cmd2 = new OleDbCommand("select BP From Products where PID='" +textBox7.Text+ "'", conn2);
            OleDbDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {

                textBox9.Text = (dr2["BP"]).ToString();

          
            }
            conn2.Close();
            //fetching vid
            OleDbConnection conn3 = new OleDbConnection();
            conn3.ConnectionString =c.ConnectionString;
            conn3.Open();
            OleDbCommand cmd3 = new OleDbCommand("select VID from GRN where GRNID='" + comboBox3.Text + "'", conn3);
            OleDbDataReader dr4 = cmd3.ExecuteReader();
            while (dr4.Read())
            {
                textBox10.Text = dr4["VID"].ToString();
            }

            conn3.Close();
         textBox11.Text = comboBox3.Text + "_I";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        string f;
        private void POID(object sender, EventArgs e)
        {

        }
        string vid, Vname, ContectPerson, cpph,GRNID,AmountPayable,DCDate;
        private void button4_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox3.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             this.groupBox1.Hide();
            this.groupBox3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            mycon c= new mycon();
            try{
            OleDbConnection conn3 = new OleDbConnection();
            conn3.ConnectionString =c.ConnectionString ;
            conn3.Open();
            OleDbCommand cmd3 = new OleDbCommand("select *from vendor where VID='" + textBox10.Text + "'", conn3);
            OleDbDataReader dr3 = cmd3.ExecuteReader();
            while (dr3.Read())
            {
                vid = textBox10.Text;
                Vname = dr3["VName"].ToString();
                ContectPerson = dr3["CPName"].ToString();
                cpph = dr3["CPPH"].ToString();

            }
            OleDbCommand cmd4 = new OleDbCommand("select *from GRN where GRNID='" + comboBox3.Text + "'", conn3);
            OleDbDataReader dr4 = cmd4.ExecuteReader();
            while (dr4.Read())
            {
                GRNID = dr4["GRNID"].ToString();
                AmountPayable = dr4["Totalprice"].ToString();
                DCDate = dr4["DCDate"].ToString();
            }
            OleDbCommand cmd5 = new OleDbCommand("Insert into Invoice(InvoiceNo,VendorID,VendorName,ContectPerson,CPPH,DCDate,AmountPayable,GRNID) values(@InvoiceNo,@VendorID,@VendorName,@ContectPerson,@CPPH,@DCDate,@AmountPayable,@GRNID)", conn3);
            cmd5.Parameters.AddWithValue("IncoiceNo", textBox11.Text);
            cmd5.Parameters.AddWithValue("VendorID", textBox10.Text);
            cmd5.Parameters.AddWithValue("VendorName", Vname);
            cmd5.Parameters.AddWithValue("ContectPers", ContectPerson);
            cmd5.Parameters.AddWithValue("CPPH", cpph);
            cmd5.Parameters.AddWithValue("DCDate", DCDate);
            cmd5.Parameters.AddWithValue("AmountPayable", AmountPayable);
            cmd5.Parameters.AddWithValue("GRNID", GRNID);
         
            OleDbConnection conn5 = new OleDbConnection();
          
            OleDbCommand cmd6 = new OleDbCommand("update GRN set Status='"+"Close"+"' where GRNID='"+comboBox3.Text+"'",conn3);
            cmd6.ExecuteReader();
            conn5.Close();
            MessageBox.Show("Record Added!");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            this.textBox8.Enabled = false;
            this.textBox9.Enabled = false;
            this.textBox11.Enabled = false;
            this.textBox6.Enabled = false;
            this.textBox7.Enabled = false;
            this.textBox10.Enabled = false;
            this.comboBox3.Enabled = false;
            this.label17.Show();
            this.button1.Hide();
            this.button2.Hide();
            this.button5.Hide();
            this.groupBox3.Text = "";
            this.groupBox3.Location = new Point(0, 42);
            this.Size = new Size(600, 275);
            this.button4.Hide();
            this.button6.Show();


        }

        private void button5_Click(object sender, EventArgs e)
        {
            vander f = new vander();
            this.Hide();
            f.Show();
        }

        private void GRN_Load(object sender, EventArgs e)
        {
            this.button6.Hide();
            this.label17.Hide();
            this.groupBox3.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("invoice printed");
            this.textBox8.Enabled = true;
            this.textBox9.Enabled = true;
            this.textBox11.Enabled = true;
            this.textBox6.Enabled = true;
            this.textBox7.Enabled = true;
            this.textBox10.Enabled = true;
            this.comboBox3.Enabled = true;
            this.label17.Hide();
            this.button1.Show();
            this.button2.Show();
            this.button5.Show();
            this.groupBox3.Text = "Invoice";
            this.groupBox3.Location = new Point(125, 55);
            this.Size = new Size(844, 468);
            this.button4.Hide();
           
        }
    }
    public class mycon
    {
        //OleDbConnection conn = new OleDbConnection();
        public string ConnectionString =@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+Environment.CurrentDirectory+"\\PC_DB.accdb";

    }
}
