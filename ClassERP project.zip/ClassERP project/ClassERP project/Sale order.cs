﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ClassERP_project
{
    public partial class Sale_order : Form
    {
        string cid, Cname, ContectPerson, cpph, GRNID, AmountPayable, DCDate;
        string[] prds = new string[50];

        int[] qty = new int[50];

        int counter = 0;
        public Sale_order()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try{
            mycon2 c = new mycon2();
            OleDbConnection conn3 = new OleDbConnection();
            conn3.ConnectionString = c.ConnectionString;
            conn3.Open();
            OleDbCommand cmd = new OleDbCommand("insert into Customer(CID,Cname,CAddress,CCity,CPH1,CPH2,CPName,CPPH,CEmail,CStatus) values(@CID,@Cname,@CAddress,@CCity,@CPH1,@CPH2,@CPName,@CPPH,@CEmail,@CStatus)", conn3);
            //          cmd.Parameters.AddWithValue("cid", (count) + "CR/2017");
            cmd.Parameters.AddWithValue("@CID", textBox1.Text);
            cmd.Parameters.AddWithValue("@Cname", textBox2.Text);
            cmd.Parameters.AddWithValue("@CAddress", textBox4.Text);
            cmd.Parameters.AddWithValue("@CCity", textBox3.Text);
            cmd.Parameters.AddWithValue("@CPH1", textBox5.Text);
            cmd.Parameters.AddWithValue("@CH2", textBox6.Text);
            cmd.Parameters.AddWithValue("@CPName", textBox7.Text);
            cmd.Parameters.AddWithValue("@CPPH", textBox8.Text);
            cmd.Parameters.AddWithValue("@CEmail", textBox9.Text);
            cmd.Parameters.AddWithValue("@CStatus", textBox10.Text);
            cmd.Parameters.AddWithValue("@Creditlimit", textBox10.Text);
            cmd.ExecuteNonQuery();
            conn3.Close();
            MessageBox.Show("Vendor Inserted");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        int a;
        private void Sale_order_Load(object sender, EventArgs e)
        {
            this.comboBox4.Hide();
            this.textBox10.Text = "inactive";
            try{
                mycon2 c = new mycon2();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select count(CID) from Customer", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                a = Convert.ToInt16(dr[0]);
                a += a + 1;
                textBox1.Text = a.ToString() + "/Con" + "/2017";

            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.comboBox4.Show();
        }

        private void comboBox4_Click(object sender, EventArgs e)
        {
            this.comboBox4.Items.Clear();
            try{
                mycon2 c = new mycon2();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionString; conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox4.Items.Add(dr["CID"]);

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            try{
                mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer  where CID='" + comboBox4.Text + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox1.Text = (dr["CID"]).ToString();
                textBox2.Text = (dr["Cname"]).ToString();
                textBox4.Text = (dr["CAddress"]).ToString();
                textBox3.Text = (dr["CCity"]).ToString();
                textBox5.Text = (dr["CPH1"]).ToString();
                textBox6.Text = (dr["CPH2"]).ToString();
                textBox7.Text = (dr["CPName"]).ToString();
                textBox8.Text = (dr["CPPH"]).ToString();
                textBox9.Text = (dr["CEmail"]).ToString();
                textBox11.Text = (dr["CreditLimit"]).ToString();

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            this.comboBox1.Items.Clear();
            try{
                mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString =c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer where CStatus='" + "inactive" + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["CID"]);

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try{
                mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString =c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer  where CID='" + comboBox1.Text + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                //textBox21.Text = (dr["CID"]).ToString();
                textBox21.Text = (dr["Cname"]).ToString();
                textBox12.Text = (dr["CAddress"]).ToString();
                textBox20.Text = (dr["CCity"]).ToString();
                textBox19.Text = (dr["CPH1"]).ToString();
                textBox15.Text = (dr["CPH2"]).ToString();
                textBox18.Text = (dr["CPName"]).ToString();
                textBox17.Text = (dr["CPPH"]).ToString();
                textBox16.Text = (dr["CEmail"]).ToString();
                textBox14.Text = (dr["CreditLimit"]).ToString();
                comboBox2.Text = (dr["CStatus"]).ToString();

            }
            conn.Close();

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try{
                mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;

            conn.Open();
            OleDbCommand cmd = new OleDbCommand("update Customer set CStatus='" + comboBox2.Text + "' where CID='" + comboBox1.Text + "'", conn);
            cmd.ExecuteReader();
            conn.Close();
            MessageBox.Show("Record Approved !");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        string id;
        private void comboBox3_Click(object sender, EventArgs e)
        {
            try{
            comboBox3.Items.Clear();
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select CID from Customer", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["CID"]);
                id = comboBox3.Text + comboBox6.Text;
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try{
            textBox22.Clear();
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer where CID='" + comboBox3.Text + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox24.Text = (dr["CName"]).ToString();
                textBox28.Text = (dr["CID"]).ToString();
                textBox26.Text = (dr["CPName"]).ToString();
                textBox25.Text = (dr["CPPH"]).ToString();
                textBox27.Text = (dr["Cname"]).ToString();

            }
            conn.Close();
            textBox22.Text += comboBox3.Text + "/" + comboBox6.Text + a.ToString();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox6_Click(object sender, EventArgs e)
        {
            try{
            comboBox6.Items.Clear();
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select PID from Products", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox6.Items.Add(dr["PID"]);

            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            try{
            textBox22.Clear();
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select count(SOID) from SO", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                a = Convert.ToInt16(dr[0]);
                a = a + 1;

            }
            textBox22.Text += comboBox3.Text + comboBox6.Text + a.ToString();

            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString = c.ConnectionString;
            conn1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select *from Products where PID='" + comboBox6.Text + "' ", conn1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                textBox34.Text = (dr1["BP"]).ToString();
                textBox35.Text = (dr1["PName"]).ToString();

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        public class mycon2
        {
            OleDbConnection conn = new OleDbConnection();
           public string ConnectionString =@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+Environment.CurrentDirectory+"\\PC_DB.accdb";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int p = Convert.ToInt32(textBox34.Text);
            int q = Convert.ToInt32(textBox33.Text);
            int a = Convert.ToInt32(textBox32.Text); a += p * q;
            textBox2.Text = a.ToString();
            textBox29.Text += comboBox6.Text + Environment.NewLine;
            textBox30.Text += textBox34.Text + Environment.NewLine;
            textBox31.Text += textBox33.Text + Environment.NewLine;
            prds[counter] = comboBox6.Text;
            qty[counter] = Convert.ToInt32(textBox33.Text);

            counter++;
        }
        int asd = 0;
        private void textBox33_TextChanged(object sender, EventArgs e)
        {
            int p = Convert.ToInt32(textBox34.Text);
            int q = Convert.ToInt32(textBox33.Text);
            asd += p * q;
            textBox32.Text = asd.ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try{
            mycon2 c = new mycon2();
            for (int i = 0; i < counter; i++)
            {
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionString;
                OleDbCommand cmd = new OleDbCommand("insert into SOproducts(SOID,PID,PQty) values(@SOID,@PID,@PQty)", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@SOID", textBox22.Text);
                cmd.Parameters.AddWithValue("@PID", textBox29.Text);
                cmd.Parameters.AddWithValue("@PQTY", textBox31.Text);
                cmd.ExecuteNonQuery();
                conn.Close();

            }
            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString = c.ConnectionString;
            OleDbCommand cmd1 = new OleDbCommand("insert into SO(SOID,DDate,Status,Approve,CID,TotalAmount) values(@SOID,@DDate,@Approve,@Status,@VID,@TotalAmount)", conn1);
            conn1.Open();
            cmd1.Parameters.AddWithValue("@SOID", textBox22.Text);
            cmd1.Parameters.AddWithValue("@DDate", dateTimePicker1.Text);
            cmd1.Parameters.AddWithValue("@Status", "open");
            cmd1.Parameters.AddWithValue("@Approve", "inactive");
            cmd1.Parameters.AddWithValue("@CID", comboBox3.Text);
            cmd1.Parameters.AddWithValue("@TotalAmount", textBox32.Text);
            cmd1.ExecuteNonQuery();
            conn1.Close();
            MessageBox.Show("Transection Completed");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox2.Show();
            this.groupBox3.Show();
            this.groupBox7.Hide();
            this.groupBox9.Hide();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox2.Show();
            this.groupBox3.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox2.Hide();
            this.groupBox3.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox2.Show();
            this.groupBox3.Show();
            this.groupBox7.Show();
            this.groupBox9.Show();
            this.groupBox10.Show();
        }

        private void comboBox7_Click(object sender, EventArgs e)
        {
            comboBox7.Items.Clear();
            try{
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select SOID from SO where Status='" + "open" + "' and Approve='" + "activate" + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox7.Items.Add(dr["SOID"]);
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            try{
            mycon2 c = new mycon2();
            // fetching PID AND PQTY for POProduct...
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select PID, PQty from SOProducts where SOID='" + comboBox7.Text + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox38.Text = dr["PID"].ToString();
                textBox37.Text = dr["PQty"].ToString();
            }

            //conn.Close();
            ////fething pname from product tble
            //OleDbConnection conn1 = new OleDbConnection();
            //conn1.ConnectionString = c.ConnectionString;
            //conn1.Open();
            //OleDbCommand cmd1 = new OleDbCommand("select *From Products where PID='"+textBox1.Text+"' ", conn1);
            //OleDbDataReader dr1 = cmd1.ExecuteReader();
            //while (dr1.Read())
            //{
            // //textBox4.Text=dr1["PName"].ToString();
            // textBox5.Text = dr1["BP"].ToString();
            //}

            //conn1.Close();
            ////fetching VID and date
            OleDbConnection conn2 = new OleDbConnection();
            conn2.ConnectionString = c.ConnectionString;
            conn2.Open();
            OleDbCommand cmd2 = new OleDbCommand("select CID , DDate , TotalAmount from SO where Soid='" + comboBox7.Text + "' ", conn2);
            OleDbDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                textBox36.Text = dr2["CID"].ToString();
                textBox23.Text = dr2["DDate"].ToString();
                textBox13.Text = dr2["TotalAmount"].ToString();
            }

            conn2.Close();
            textBox39.Text = "GRN//" + comboBox7.Text;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            mycon2 c = new mycon2();
            try{
            // fetching PID AND PQTY for POProduct...
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("insert into GRN (GRNID,BaseDocument,Status,CID,DCDate,GRNDate,Totalprice,Remarks) values(@GRNID,@BaseDocument,@Status,@CID,@DCDate,@GRNDate,@Totalprice,@Remarks)", conn);
            cmd.Parameters.AddWithValue("GRNID", textBox39.Text);
            cmd.Parameters.AddWithValue("BaseDocument", comboBox7.Text);
            cmd.Parameters.AddWithValue("Status", "open");
            cmd.Parameters.AddWithValue("CID", textBox36.Text);
            cmd.Parameters.AddWithValue("DCDate", textBox23.Text);
            cmd.Parameters.AddWithValue("DDate", dateTimePicker2.Text);
            cmd.Parameters.AddWithValue("Totalprice", textBox13.Text);
            cmd.Parameters.AddWithValue("Remarks", richTextBox2.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            //update status
            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString = c.ConnectionString;
            conn1.Open();
            OleDbCommand cmd1 = new OleDbCommand("update SO set Status='" + "Close" + "' where SOID='" + comboBox7.Text + "'", conn1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();

            MessageBox.Show("GRN COMPLETED");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void comboBox5_Click(object sender, EventArgs e)
        {
            try{
            comboBox5.Items.Clear();
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select GRNID from GRN where Status='" + "open" + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox5.Items.Add(dr["GRNID"]);
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        string f = "";
        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            try{
            mycon2 c = new mycon2();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select BaseDocument from GRN where GRNID='" + comboBox5.Text + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox45.Text = (dr["BaseDocument"]).ToString();
            }

            conn.Close();
            //fetching pid and pquantity
            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString = c.ConnectionString;
            conn1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select PID ,PQty from SOProducts where SOID='" + textBox45.Text + "' ", conn1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                textBox44.Text = (dr1["PID"]).ToString();
                f = textBox7.Text;
                textBox43.Text = (dr1["PQty"]).ToString();

            }
            conn1.Close();
            //fetching price
            OleDbConnection conn2 = new OleDbConnection();
            conn2.ConnectionString = c.ConnectionString;
            conn2.Open();

            OleDbCommand cmd2 = new OleDbCommand("select BP From Products where PID='" + "kg200" + "'", conn2);
            OleDbDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {

                textBox42.Text = (dr2["BP"]).ToString();


            }
            conn2.Close();
            //fetching vid
            OleDbConnection conn3 = new OleDbConnection();
            conn3.ConnectionString = c.ConnectionString;
            conn3.Open();
            OleDbCommand cmd3 = new OleDbCommand("select CID from GRN where GRNID='" + comboBox5.Text + "'", conn3);
            OleDbDataReader dr4 = cmd3.ExecuteReader();
            while (dr4.Read())
            {
                textBox41.Text = dr4["CID"].ToString();
            }

            conn3.Close();
            textBox40.Text = "I/" + comboBox5.Text;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            try{
            mycon c = new mycon();
            OleDbConnection conn3 = new OleDbConnection();
            conn3.ConnectionString = c.ConnectionString;
            conn3.Open();
            OleDbCommand cmd3 = new OleDbCommand("select *from Customer where CID='" + textBox41.Text + "'", conn3);
            OleDbDataReader dr3 = cmd3.ExecuteReader();
            while (dr3.Read())
            {
                cid = textBox41.Text;
                //Vname = dr3["VName"].ToString();
                //ContectPerson = dr3["CPName"].ToString();
                cpph = dr3["CPPH"].ToString();

            }
            OleDbCommand cmd4 = new OleDbCommand("select *from GRN where GRNID='" + comboBox5.Text + "'", conn3);
            OleDbDataReader dr4 = cmd4.ExecuteReader();
            while (dr4.Read())
            {
                GRNID = dr4["GRNID"].ToString();
                AmountPayable = dr4["Totalprice"].ToString();
                DCDate = dr4["DCDate"].ToString();
            }
            OleDbCommand cmd5 = new OleDbCommand("insert into Invoice(InvoiceNo,CustomerID,CustomerName,ContectPerson,CPPH,DCDate,AmountPayable,GRNID) values(@InvoiceNo,@VendorID,@VendorName,@ContectPerson,@CPPH,@DCDate,@AmountPayable,@GRNID)", conn3);
            cmd5.Parameters.AddWithValue("IncoiceNo", textBox40.Text);
            cmd5.Parameters.AddWithValue("CustomerID", textBox41.Text);
            cmd5.Parameters.AddWithValue("CustomerName", Cname);
            cmd5.Parameters.AddWithValue("ContectPers", ContectPerson);
            cmd5.Parameters.AddWithValue("CPPH", cpph);
            cmd5.Parameters.AddWithValue("DCDate", DCDate);
            cmd5.Parameters.AddWithValue("AmountPayable", AmountPayable);
            cmd5.Parameters.AddWithValue("GRNID", GRNID);

            OleDbConnection conn5 = new OleDbConnection();

            OleDbCommand cmd6 = new OleDbCommand("update GRN set Status='" + "Close" + "' where GRNID='" + comboBox5.Text + "'", conn3);
            cmd6.ExecuteReader();
            conn5.Close();
            MessageBox.Show("Record Added!");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox2.Show();
            this.groupBox3.Show();
            this.groupBox7.Show();
            this.groupBox9.Hide();
            this.groupBox10.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.groupBox1.Show();
            this.groupBox2.Show();
            this.groupBox3.Show();
            this.groupBox7.Show();
            this.groupBox9.Show();
            this.groupBox10.Hide();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try{
            mycon c = new mycon();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;

            conn.Open();
            OleDbCommand cmd = new OleDbCommand("update SO set Approve='" + comboBox8.Text + "' where SOID='" + comboBox10.Text + "'", conn);
            cmd.ExecuteReader();
            conn.Close();
            MessageBox.Show("Record Approved !");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox9_Click(object sender, EventArgs e)
        {

        }

       

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Aliyar\Desktop\PC_DB1.accdb");
            //OleDbCommand cmd = new OleDbCommand("Select * From SO where SOID='" + comboBox10.Text + "'", con);
            //DataTable table = new DataTable();
            //OleDbDataAdapter adapter = new OleDbDataAdapter();
            //adapter.SelectCommand = cmd;
            //adapter.Fill(table);
            //dataGridView1.DataSource = table;

            //dataGridView1.ReadOnly = true;

            //con.Open();
            //cmd.ExecuteNonQuery();
            //con.Close();
            try{
                mycon c = new mycon();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select  cid ,ddate from SO where Soid='" + comboBox10.Text + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox49.Text = (dr["DDate"].ToString());
                textBox52.Text = (dr["CID"]).ToString();
                comboBox8.Text = "inactive";
            }
            conn.Close();
            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString =c.ConnectionString;
            conn1.Open();

            for (int i = 0; i < 1; i++)
            {
                OleDbCommand cmd1 = new OleDbCommand("select PID , PQty from SOProducts where SOID='" + comboBox10.Text + "' ", conn1);
                OleDbDataReader dr1 = cmd1.ExecuteReader();
                while (dr1.Read())
                {

                    textBox51.Text += (dr1["PID"]).ToString();
                    textBox50.Text += (dr1["PQty"]).ToString() + Environment.NewLine;
                }

            }
            conn1.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox10_Click(object sender, EventArgs e)
        {
            this.textBox52.Clear();
            this.textBox49.Clear();
            this.textBox51.Clear();
            this.textBox50.Clear();
            this.comboBox10.Items.Clear();
            try{
            mycon c= new mycon();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select SOID from SO where Approve='" + "inactive" + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox10.Items.Add(dr["SOID"]);
            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }


}