﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ClassERP_project
{
    public partial class vander : Form
    {
        string[] prds = new string[50];

        int[] qty = new int[50];

        int counter = 0;
        public vander()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("insert into Vendor (VID,Vname,VAddress,VCity,PH1,PH2,CPName,CPPH,VEmail,VStatus) values(@VID,@Vname,@VAddress,@VCity,@PH1,@PH2,@CPName,@CPPH,@VEmail,@VStatus)", conn);
                //          cmd.Parameters.AddWithValue("cid", (count) + "CR/2017");
                cmd.Parameters.AddWithValue("@VID", textBox23.Text);
                cmd.Parameters.AddWithValue("@Vname", textBox22.Text);
                cmd.Parameters.AddWithValue("@VAddress", textBox21.Text);
                cmd.Parameters.AddWithValue("@VCity", textBox12.Text);
                cmd.Parameters.AddWithValue("@PH1", textBox20.Text);
                cmd.Parameters.AddWithValue("@PH2", textBox16.Text);
                cmd.Parameters.AddWithValue("@ContectPerson", textBox19.Text);
                cmd.Parameters.AddWithValue("@CPPH", textBox18.Text);
                cmd.Parameters.AddWithValue("@VEmail", textBox17.Text);
                cmd.Parameters.AddWithValue("@VStatus", textBox13.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Vendor Inserted");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.comboBox1.Show();
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            try
            {
                this.comboBox1.Items.Clear();
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select VID from Vendor", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox1.Items.Add(dr["VID"]);

                }
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select *from Vendor where VID='" + comboBox1.Text + "' ", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    textBox23.Text = (dr["VID"]).ToString();
                    textBox22.Text = (dr["Vname"]).ToString();
                    textBox21.Text = (dr["VAddress"]).ToString();
                    textBox12.Text = (dr["VCity"]).ToString();
                    textBox20.Text = (dr["PH1"]).ToString();
                    textBox16.Text = (dr["PH2"]).ToString();
                    textBox19.Text = (dr["CPName"]).ToString();
                    textBox18.Text = (dr["CPPH"]).ToString();
                    textBox17.Text = (dr["VEmail"]).ToString();
                    textBox13.Text = (dr["VStatus"]).ToString();
                }
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);}

        }
        int a = 1;
        int count = 0;
        int X = 3, Y = 0;
        private void vander_Load(object sender, EventArgs e)
        {
            this.comboBox7.Show();
            string erp = "\t\t\v\v\t\tAfter Thank you this is an ERP of meterail production management desiged by SAR Production to thier own comany\n"+
                "this basically manages the production and vendor custemor needs in an orgaization ...."+
            "Note:::: Find Errors and do comform us/....";
            richTextBox1.Text = "\v\v\v\v\v\v\v\v\v\v\v\t\tSAR Production is a Company of three  they ware study in the same collage and brought up in unerversity and started this..\n so do appretiate them with love and support \n\n Thank You " +
                erp;
            //this.groupBox7.Hide();
            this.groupBox3.Hide();
            int z = Convert.ToInt16("0");
            textBox2.Text = z.ToString();
            int q = Convert.ToInt16("1");
            textBox29.Text = q.ToString();
            try
            {
                myconnection c3 = new myconnection();
                OleDbConnection conn3 = new OleDbConnection();
                conn3.ConnectionString = c3.ConnectionStr;
                conn3.Open();
                OleDbCommand cmd1 = new OleDbCommand("select PID from Products", conn3);
                OleDbDataReader dr1 = cmd1.ExecuteReader();
                while (dr1.Read())
                {
                    comboBox6.Items.Add(dr1["PID"]);
                }

                conn3.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            this.comboBox1.Hide();
            this.comboBox2.Hide();
            this.groupBox1.Visible = false;
            this.groupBox2.Visible = false;
            this.groupBox8.Hide();
            try
            {
                myconnection c4 = new myconnection();
                OleDbConnection conn4 = new OleDbConnection();
                conn4.ConnectionString = c4.ConnectionStr;
                conn4.Open();
                OleDbCommand cmd = new OleDbCommand("select VID from Vendor", conn4);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    a = Convert.ToInt32((dr["VID"]));
                    count++;
                    textBox23.Text = (a + 1).ToString();
                }

                conn4.Close();

                textBox13.Text = "Inactive";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
       
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("update Vendor set VName='" + textBox22.Text + "', VID='" + textBox23.Text +
                 "',VAddress='" + textBox21 + "', VCity='" + textBox12.Text + "',PH1='" + textBox20.Text + "',PH2='" + textBox16.Text +
                 "',CPName='" + textBox19.Text + "', CPPH='" + textBox18.Text + "',VEmail='" + textBox17.Text + "',VStatus='" + textBox13.Text + "' where VID='" + comboBox1.Text + "'", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                conn.Close();
                MessageBox.Show("Record updated");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_ClientSizeChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;

                conn.Open();
                OleDbCommand cmd = new OleDbCommand("update Vendor set VStatus='" + comboBox3.Text + "' where VID='" + comboBox2.Text + "'", conn);
                cmd.ExecuteReader();
                conn.Close();
                MessageBox.Show("Vender Activaed !");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select *from Vendor where VID='" + comboBox2.Text + "' ", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    textBox10.Text = (dr["VID"]).ToString();
                    textBox9.Text = (dr["Vname"]).ToString();
                    textBox8.Text = (dr["VAddress"]).ToString();
                    textBox1.Text = (dr["VCity"]).ToString();
                    textBox7.Text = (dr["PH1"]).ToString();
                    textBox3.Text = (dr["PH2"]).ToString();
                    textBox6.Text = (dr["CPName"]).ToString();
                    textBox5.Text = (dr["CPPH"]).ToString();
                    textBox4.Text = (dr["VEmail"]).ToString();
                    comboBox3.Text = (dr["VStatus"]).ToString();
                }
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox2_Click_1(object sender, EventArgs e)
        {
            this.comboBox2.Items.Clear();
            myconnection c = new myconnection();
            try
            {
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select VID from Vendor where VStatus='" + "Inactive" + "'", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox2.Items.Add(dr["VID"]);

                }
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        //    this.richTextBox1.Visible = false;
            label49.Visible = false;
            this.groupBox1.Visible = true;
            this.groupBox2.Visible = false;
            this.groupBox3.Hide();
            this.groupBox8.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.label49.Visible = false;
            this.richTextBox1.Visible = false;
            this.groupBox1.Visible = false;
            this.groupBox2.Visible = true;
            this.groupBox3.Hide();
            this.groupBox8.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.comboBox2.Visible = true;
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
        int c = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            label12.Location = new Point(X, Y);
            X++;
            if (X == 915)
            {
                X = -400;
            }
            c++;
            
        }

        private void comboBox5_Click(object sender, EventArgs e)
        {
            comboBox5.Items.Clear();
            myconnection c = new myconnection();
            try
            {
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select VID from Vendor", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    comboBox5.Items.Add(dr["VID"]);
                }

                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select *from Vendor where VID='" + comboBox5.Text + "' ", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    textBox11.Text = (dr["VName"]).ToString();
                    textBox14.Text = (dr["PH1"]).ToString();
                    textBox26.Text = (dr["VDepart"]).ToString();
                    textBox25.Text = (dr["CPName"]).ToString();
                    textBox24.Text = (dr["CPPH"]).ToString();

                }
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                myconnection c = new myconnection();
                OleDbConnection conn = new OleDbConnection();
                conn.ConnectionString = c.ConnectionStr;
                conn.Open();
                OleDbCommand cmd = new OleDbCommand("select *from Products where PID='" + comboBox6.Text + "' ", conn);
                OleDbDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    textBox27.Text = (dr["PName"]).ToString();
                    textBox28.Text = (dr["BP"]).ToString();

                }
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int p = Convert.ToInt32(textBox28.Text);
            int q = Convert.ToInt32(textBox29.Text);
            int a = Convert.ToInt32(textBox2.Text); a += p * q;
            textBox2.Text = a.ToString();
            textBox15.Text += comboBox6.Text + Environment.NewLine;
            textBox30.Text += textBox28.Text + Environment.NewLine;
            textBox31.Text += textBox29.Text + Environment.NewLine;
            prds[counter] = comboBox6.Text;
            qty[counter] = Convert.ToInt32(textBox29.Text);

            counter++;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try{
            myconnection c = new myconnection();
            for (int i = 0; i < counter; i++)
            {
                OleDbConnection conn = new OleDbConnection();

                conn.ConnectionString = c.ConnectionStr;
                OleDbCommand cmd = new OleDbCommand("insert into POproducts(POID,PID,PQty) values(@POID,@PID,@PQty)", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@POID", comboBox4.Text);
                cmd.Parameters.AddWithValue("@PID", textBox15.Text);
                cmd.Parameters.AddWithValue("@PQTY", textBox31.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString = c.ConnectionStr;
            OleDbCommand cmd1 = new OleDbCommand("insert into PO(POID,DDate,Status,Approve,VID,TotalAmount) values(@POID,@DDate,@Approve,@Status,@VID,@TotalAmount)", conn1);
            conn1.Open();
            cmd1.Parameters.AddWithValue("@POID", comboBox4.Text);
            cmd1.Parameters.AddWithValue("@DDate", dateTimePicker1.Text);
            cmd1.Parameters.AddWithValue("@Status", "open");
            cmd1.Parameters.AddWithValue("@Approve", "inactive");
            cmd1.Parameters.AddWithValue("@VID", comboBox5.Text);
            cmd1.Parameters.AddWithValue("@TotalAmount", textBox2.Text);
            cmd1.ExecuteNonQuery();
            conn1.Close();
            MessageBox.Show("Transection Completed");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_Click(object sender, EventArgs e)
        {
            try{
            myconnection c = new myconnection();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionStr;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select count(POID) from PO", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                a = Convert.ToInt16(dr[0]);
                a += a + 1;
                comboBox4.Text = a.ToString() + "/Con" + "/2017";
            }

            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label49.Visible = false;
            this.richTextBox1.Visible = false;
            this.groupBox3.Show();
            this.groupBox1.Hide();
            this.groupBox2.Hide();
            this.groupBox7.Hide();
            this.groupBox8.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            label49.Visible = false;
            this.richTextBox1.Visible = false;
            this.groupBox1.Hide();
            this.groupBox2.Hide();
            this.groupBox3.Show();
            this.groupBox7.Show();
            this.groupBox8.Hide();
        }
        string poi;
        private void comboBox7_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try{
            myconnection c = new myconnection();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionStr;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select  vid ,ddate from PO where poid='"+comboBox7.Text+"'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox32.Text = (dr["DDate"].ToString());
                textBox37.Text = (dr["VID"]).ToString();
                comboBox8.Text = "inactive";
            }
            conn.Close();
            OleDbConnection conn1 = new OleDbConnection();
            conn1.ConnectionString =c.ConnectionStr;
            conn1.Open();
            
            for(int i =0;i<1;i++){
            OleDbCommand cmd1 = new OleDbCommand("select *from POProducts where POID='"+comboBox7.Text+"' ", conn1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
              
               textBox34.Text += (dr1["PID"]).ToString();
                textBox33.Text += (dr1["PQty"]).ToString()+Environment.NewLine;
            }
               
        }
            conn1.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            try{
            myconnection c = new myconnection();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionStr;

            conn.Open();
            OleDbCommand cmd = new OleDbCommand("update PO set Approve='" + comboBox8.Text + "' where POID='" + comboBox7.Text + "'", conn);
            cmd.ExecuteReader();
            conn.Close();
            MessageBox.Show("Record Approved !");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void label39_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void textBox33_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox34_TextChanged(object sender, EventArgs e)
        {

        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void label46_Click(object sender, EventArgs e)
        {

        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox7_ClientSizeChanged(object sender, EventArgs e)
        {

        }

        private void comboBox7_Click_1(object sender, EventArgs e)
        {

            this.textBox32.Clear();
            this.textBox33.Clear();
            this.textBox34.Clear();
            this.textBox37.Clear();
            this.comboBox7.Items.Clear();
            try{
            myconnection c = new myconnection();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionStr;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select POID from PO where Approve='" + "inactive" + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox7.Items.Add(dr["POID"]);
            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label49.Visible = false; 
            this.richTextBox1.Visible = false;
            this.comboBox1.Hide();
            this.comboBox2.Hide();
            this.groupBox1.Visible = false;
            this.groupBox2.Visible = false;
            this.groupBox8.Show();
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            try{
            myconnection c2 = new myconnection();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c2.ConnectionStr;
            OleDbCommand cmd = new OleDbCommand("insert into products(PID,Pname,BasePrice) values(@PID,@Pname,@BasePrice)", conn);
            conn.Open();
            cmd.Parameters.AddWithValue("@PID", textBox35.Text);
            cmd.Parameters.AddWithValue("@PName", textBox36.Text);
            cmd.Parameters.AddWithValue("@BasePrice", textBox38.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Products Details has been Added");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Form1 mainform = new Form1();
            this.Hide();
            mainform.Show();
        }

        private void groupBox8_Enter(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.Hide();
            GRN f = new GRN();
            f.Show();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        }
    public class myconnection
    {
       public string ConnectionString =@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+Environment.CurrentDirectory+"\\PC_DB.accdb";
    }
    }
