﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ClassERP_project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int count = 0;
        int x = 8, y = 9;
        int a = 1;
        int c = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            PROGRESSBARTIMER.Start();
           


            this.label31.BackColor = Color.Firebrick;
            //this.panel6.Hide();
            this.AcceptButton = loginbtn;
            this.comboboxS.Visible = false;
            this.textBox33.Text = "Inactive";
            this.textBox33.ReadOnly = true;
            this.textBox1.ReadOnly = true;
            this.panel5.Visible = false;
            this.panel1.Visible = true;
            this.panel4.Visible = false;
            this.panel3.Visible = false;
            button2.Visible = false;
            button7.Visible = false;
            mycon12 c = new mycon12();
            OleDbConnection conn = new OleDbConnection();
            try{
            conn.ConnectionString = c.ConnectionString;

            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select CID from Customer", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                a = Convert.ToInt32((dr["CID"]));
                 count++;
                 textBox1.Text = (a+1).ToString();
            }
            
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.label28.ForeColor = Color.Firebrick;
            panel3.Visible = true;
            this.panel4.Visible = true;
            this.panel5.Visible = true;
            this.label28.Text = "CUSTEMER MASTER ADD PANAL ";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            button2.Visible = true;
            button7.Visible = true;
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            this.panel4.Visible = true;
            this.panel5.Visible = true;
            this.label28.Text = "CUSTEMER MASTER APPROVAL PANAL ";
            this.label28.ForeColor = Color.Green;
        }

        

        private void button4_Click(object sender, EventArgs e)
        {
            try{
            mycon12 c = new mycon12();
            OleDbConnection conn = new OleDbConnection();
           // conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Environment.CurrentDirectory + @"//Users\Aliyar\Desktop\PC_DB.accdb";
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("insert into Customer (CID,Cname,CAddress,City,PH1,PH2,ContectPerson,CPPH,CEmail,CreditLimit,CStatus,CGroup) values(@CID,@Cname,@CAddress,@City,@PH1,@PH2,@ContectPerson,@CPPH,@CEmail,@CreditLimit,@CStatus,@CGroup)", conn);
  //          cmd.Parameters.AddWithValue("cid", (count) + "CR/2017");
            cmd.Parameters.AddWithValue("@CID",textBox1.Text);
            cmd.Parameters.AddWithValue("@Cname", textBox2.Text);
            cmd.Parameters.AddWithValue("@CAddress", textBox5.Text);
            cmd.Parameters.AddWithValue("@City", textBox3.Text);
            cmd.Parameters.AddWithValue("@PH1", textBox4.Text);
            cmd.Parameters.AddWithValue("@PH2", textBox9.Text);
            cmd.Parameters.AddWithValue("@ContectPerson", textBox8.Text);
            cmd.Parameters.AddWithValue("@CPPH", textBox7.Text);
            cmd.Parameters.AddWithValue("@CEmail", textBox6.Text);
            cmd.Parameters.AddWithValue("@CreditLimit", textBox11.Text);
            cmd.Parameters.AddWithValue("@CStatus", textBox33.Text);
            cmd.Parameters.AddWithValue("@CGroup", textBox10.Text);
            
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Record Inserted");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void loginbtn_Click_1(object sender, EventArgs e)
        {
            
        }

          

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }


        private void button1_Click(object sender, EventArgs e)
        {

        }
        int t = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;
            Timelbl.Text = t.ToString()+" : Wait";
            if(t==1100)
            {
                this.panel6.Visible = false;
            }
            label31.Location = new Point(x,y);
            x++;
            if(x==1200)
            {
                x = -450;
            }
        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void serchbtn_Click(object sender, EventArgs e)
        {
            this.comboboxS.Visible = true;
        }

       

        private void SearchcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            mycon12 c = new mycon12();
            OleDbConnection conn = new OleDbConnection();
            try{
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer where CID='" + comboBox3.Text + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox23.Text = (dr["CID"]).ToString();
                textBox22.Text = (dr["Cname"]).ToString();
                textBox12.Text = (dr["CAddress"]).ToString();
                textBox21.Text = (dr["City"]).ToString();
                textBox20.Text = (dr["PH1"]).ToString();
                textBox16.Text = (dr["PH2"]).ToString();
                textBox19.Text = (dr["ContectPerson"]).ToString();
                textBox18.Text = (dr["CPPH"]).ToString();
                textBox17.Text = (dr["CEmail"]).ToString();
                textBox14.Text = (dr["CreditLimit"]).ToString();
                comboBox1.Text = (dr["CStatus"]).ToString();
                textBox13.Text = (dr["CGroup"]).ToString();
            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboboxS_SelectedIndexChanged(object sender, EventArgs e)
        {
            try{
            mycon12 c = new mycon12();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Customer where CID='" + comboboxS.Text + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox1.Text = (dr["CID"]).ToString();
                textBox2.Text = (dr["Cname"]).ToString();
                textBox5.Text = (dr["CAddress"]).ToString();
                textBox3.Text = (dr["City"]).ToString();
                textBox4.Text = (dr["PH1"]).ToString();
                textBox9.Text = (dr["PH2"]).ToString();
                textBox8.Text = (dr["ContectPerson"]).ToString();
                textBox7.Text = (dr["CPPH"]).ToString();
                textBox6.Text = (dr["CEmail"]).ToString();
                textBox11.Text = (dr["CreditLimit"]).ToString();
                textBox33.Text = (dr["CStatus"]).ToString();
                textBox10.Text = (dr["CGroup"]).ToString();
            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }


        private void rectangleShape1_Click(object sender, EventArgs e)
        {

        }

       

        private void textBox4_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == Convert.ToChar(Keys.Back))
            {

            }
            else
                e.Handled = true;
        }

        private void loginbtn_Click_4(object sender, EventArgs e)
        {
            if (textBox24.Text == "cm" && textBox15.Text == "123")
            {
                this.panel3.Visible = true;
                this.panel4.Visible = false;
                this.panel5.Visible = false;
            }
            if (textBox24.Text == "ap" && textBox15.Text == "1234")
            {
                this.panel5.Visible = false;
                panel3.Visible = true;
                panel4.Visible = true;
            }
        }

        private void comboBox3_Click_1(object sender, EventArgs e)
        {
            try{
            mycon12 c = new mycon12();
            this.comboBox3.Items.Clear();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select CID from Customer where CStatus='" + "Inactive" + "' ", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["CID"]);

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox3_SelectedIndexChanged_2(object sender, EventArgs e)
        {
          
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            try{
            mycon12 c = new mycon12();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;

            conn.Open();
            OleDbCommand cmd = new OleDbCommand("update Customer set CStatus='" + comboBox1.Text + "' where CID='" + comboBox3.Text + "'", conn);
            cmd.ExecuteReader();
            conn.Close();
            MessageBox.Show("Record Approved !");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {

            if (textBox24.Text == "cm" && textBox15.Text == "123")
            {
                this.panel3.Visible = true;
                this.panel4.Visible = false;
                this.panel5.Visible = false;
            }
            if (textBox24.Text == "ap" && textBox15.Text == "1234")
            {
                this.panel5.Visible = false;
                panel3.Visible = true;
                panel4.Visible = true;
            }
            this.AcceptButton = loginbtn;
        }

        private void SearchcomboBox_Click(object sender, EventArgs e)
        {
            try{
            mycon12 c = new mycon12();
             this.comboboxS.Items.Clear();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select CID from Customer where CStatus='" + "inactive" + "'", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboboxS.Items.Add(dr["CID"]);

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void comboboxS_Click(object sender, EventArgs e)
        {
            mycon12 c = new mycon12();
            this.comboboxS.Items.Clear();
            try{
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("select CID from Customer", conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboboxS.Items.Add(dr["CID"]);

            }
            conn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            try{
            mycon12 c = new mycon12();
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = c.ConnectionString;
            conn.Open();
            OleDbCommand cmd = new OleDbCommand("update Customer set CID='" +
            textBox1.Text+ "',Cname='" +
            textBox2.Text + "',CAddress='" +
            textBox4.Text +  Convert.ToInt32("',PH1='") +
            textBox8.Text + "',City='"+
            textBox9.Text + Convert.ToInt32("',PH2='") +
            textBox8.Text + "',ContectPerson='" +
            textBox7.Text + Convert.ToInt32("',CPPH='") +
                textBox6.Text + "',CEmail='" +
                Convert.ToInt32(textBox11.Text) + "',CreditLimit='" +
                textBox33.Text + "',CStatus='" +
                textBox10.Text + "'where CID='" + comboboxS.Text + "'",conn);
            OleDbDataReader dr = cmd.ExecuteReader();
            conn.Close();
            MessageBox.Show("Record updated");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            vander V1 = new vander();
            V1.Show();
            this.Hide();
        }   
    }
    public class mycon12
    {
        //OleDbConnection conn = new OleDbConnection();
         public string ConnectionString =@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+Environment.CurrentDirectory+"\\PC_DB.accdb";
    }
}
